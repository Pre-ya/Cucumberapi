package utils;

public class Endpoints {
    public static final String userEndpoint="users";
    public static final String commentsEndpoint="comments";
    public static final String PostsEndpoints="posts";

    public static final String TodosEndpoints="todos";

}
