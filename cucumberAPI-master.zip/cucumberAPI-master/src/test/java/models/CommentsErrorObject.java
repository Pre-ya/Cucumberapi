package models;

import lombok.Getter;

@Getter
public class CommentsErrorObject {
    private String field;
    private String message;
}
