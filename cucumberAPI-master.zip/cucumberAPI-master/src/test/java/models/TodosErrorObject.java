package models;

import lombok.Getter;

@Getter
public class TodosErrorObject {
    private String field;
    private String message;
}
