package models;

import lombok.Getter;

@Getter
public class PostsErrorObject {
    private String field;
    private String message;
}
