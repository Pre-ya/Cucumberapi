package models;

import lombok.Getter;

@Getter
public class UserErrorObject {

    private String field;
    private String message;
}
